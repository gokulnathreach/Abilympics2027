import { useState } from 'react';
import Navbar      from './components/Navbar';
import ProductsPage from './pages/ProductsPage';
import AddPage      from './pages/AddPage';
import ChartsPage   from './pages/ChartsPage';

export default function App() {
  const [active, setActive] = useState('products');

  const pages = { products: <ProductsPage />, add: <AddPage />, charts: <ChartsPage /> };

  return (
    <div className="min-vh-100 bg-light">
      <Navbar active={active} setActive={setActive} />
      <div className="container-fluid py-4 px-4">
        {pages[active]}
      </div>
    </div>
  );
}
