import Charts from '../components/Charts';
export default function ChartsPage() {
  return <Charts />;
}
