import ProductForm from '../components/ProductForm';

export default function AddPage() {
  return (
    <div className="row justify-content-center">
      <div className="col-md-6">
        <ProductForm />
      </div>
    </div>
  );
}
