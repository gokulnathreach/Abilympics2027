import { useState } from 'react';
import ProductTable from '../components/ProductTable';
import ProductForm  from '../components/ProductForm';

export default function ProductsPage() {
  const [editing,  setEditing]  = useState(null);
  const [refresh,  setRefresh]  = useState(0);
  const [showForm, setShowForm] = useState(false);

  const handleEdit = (product) => { setEditing(product); setShowForm(true); };

  const handleDone = () => { setEditing(null); setShowForm(false); setRefresh(r => r + 1); };

  return (
    <div className="row g-4">
      {/* Table — always visible */}
      <div className={showForm ? 'col-md-8' : 'col-12'}>
        <ProductTable onEdit={handleEdit} refresh={refresh} />
      </div>

      {/* Inline Edit Panel */}
      {showForm && (
        <div className="col-md-4">
          <ProductForm editing={editing} onDone={handleDone} />
        </div>
      )}
    </div>
  );
}
