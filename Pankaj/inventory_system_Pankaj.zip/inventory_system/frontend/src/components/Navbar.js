export default function Navbar({ active, setActive }) {
  const links = [
    { key: 'products',    label: 'Products' },
    { key: 'add',         label: 'Add Product' },
    { key: 'charts',      label: 'Charts' },
    // { key: 'products', icon: 'bi-box-seam',    label: 'Products' },
    // { key: 'add',      icon: 'bi-plus-circle',  label: 'Add Product' },
    // { key: 'charts',   icon: 'bi-bar-chart',    label: 'Charts' },
  ];

  return (
    <nav className="navbar navbar-expand navbar-dark bg-dark px-4">
      <span className="navbar-brand fw-bold">
        <i className="bi bi-boxes me-2"></i>Inventory
      </span>
      <ul className="navbar-nav">
        {links.map(l => (
          <li className="nav-item" key={l.key}>
            <button
              className={`nav-link btn btn-link ${active === l.key ? 'active fw-bold text-white' : 'text-secondary'}`}
              onClick={() => setActive(l.key)}
            >
              <i className={`bi ${l.icon} me-1`}></i>{l.label}
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );
}
