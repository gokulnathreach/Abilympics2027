import { useState, useEffect, useCallback } from 'react';
import { getProducts, deleteProduct, exportExcel } from '../utils/api';
import SearchBar from './SearchBar';

export default function ProductTable({ onEdit, refresh }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading]   = useState(false);

  const load = useCallback((params = {}) => {
    setLoading(true);
    getProducts(params).then(r => setProducts(r.data)).finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load, refresh]);

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete "${name}"?`)) return;
    await deleteProduct(id);
    load();
  };

  const handleExport = async () => {
    const r = await exportExcel();
    const url = URL.createObjectURL(new Blob([r.data]));
    const a = document.createElement('a');
    a.href = url; a.download = 'inventory.xlsx'; a.click();
  };

  const badge = qty =>
    qty === 0   ? 'bg-danger' :
    qty <= 5    ? 'bg-warning text-dark' : 'bg-success';

  return (
    <div>
      <SearchBar onSearch={load} />

      <div className="d-flex justify-content-between align-items-center mb-2">
        <span className="text-muted small">{products.length} product(s)</span>
        <button className="btn btn-success btn-sm" onClick={handleExport}>
          <i className="bi bi-file-earmark-excel me-1"></i>Export Excel
        </button>
      </div>

      {loading ? (
        <div className="text-center py-4"><div className="spinner-border text-primary"></div></div>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover table-bordered align-middle">
            <thead className="table-dark">
              <tr>
                <th>#</th><th>Name</th><th>Category</th>
                <th>Qty</th><th>Price (₹)</th><th>Supplier</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.length === 0 ? (
                <tr><td colSpan={7} className="text-center text-muted">No products found</td></tr>
              ) : products.map((p, i) => (
                <tr key={p.id}>
                  <td>{i + 1}</td>
                  <td className="fw-semibold">{p.name}</td>
                  <td><span className="badge bg-secondary">{p.category_name || '—'}</span></td>
                  <td><span className={`badge ${badge(p.quantity)}`}>{p.quantity}</span></td>
                  <td>₹{parseFloat(p.price).toFixed(2)}</td>
                  <td>{p.supplier || '—'}</td>
                  <td>
                    <button className="btn btn-sm btn-outline-primary me-1" onClick={() => onEdit(p)}>
                      <i className="bi bi-pencil"></i>
                    </button>
                    <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(p.id, p.name)}>
                      <i className="bi bi-trash"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
