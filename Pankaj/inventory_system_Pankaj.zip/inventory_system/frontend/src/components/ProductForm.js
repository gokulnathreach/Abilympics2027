import { useState, useEffect } from 'react';
import { createProduct, updateProduct, getCategories, createCategory } from '../utils/api';

const EMPTY = { name: '', category: '', quantity: '', price: '', supplier: '' };

export default function ProductForm({ editing, onDone }) {
  const [form, setForm]         = useState(EMPTY);
  const [categories, setCats]   = useState([]);
  const [newCat, setNewCat]     = useState('');
  const [msg, setMsg]           = useState('');

  useEffect(() => {
    getCategories().then(r => setCats(r.data));
    if (editing) setForm(editing);
    else setForm(EMPTY);
  }, [editing]);

  const handle = e => setForm({ ...form, [e.target.name]: e.target.value });

  const addCategory = async () => {
    if (!newCat.trim()) return;
    const r = await createCategory({ name: newCat });
    setCats([...categories, r.data]);
    setForm({ ...form, category: r.data.id });
    setNewCat('');
  };

  const submit = async (e) => {
    e.preventDefault();
    try {
      editing ? await updateProduct(editing.id, form)
              : await createProduct(form);
      setMsg('✅ Saved!');
      setForm(EMPTY);
      setTimeout(() => { setMsg(''); onDone && onDone(); }, 1000);
    } catch { setMsg('❌ Error saving.'); }
  };

  return (
    <div className="card shadow-sm">
      <div className="card-header bg-primary text-white">
        <i className="bi bi-pencil-square me-2"></i>
        {editing ? 'Edit Product' : 'Add New Product'}
      </div>
      <div className="card-body">
        {msg && <div className="alert alert-info py-2">{msg}</div>}
        <form onSubmit={submit}>
          {/* Name */}
          <div className="mb-3">
            <label className="form-label">Product Name *</label>
            <input name="name" value={form.name} onChange={handle}
                   className="form-control" required />
          </div>

          {/* Category */}
          <div className="mb-3">
            <label className="form-label">Category</label>
            <div className="input-group">
              <select name="category" value={form.category} onChange={handle}
                      className="form-select">
                <option value="">-- Select --</option>
                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div className="input-group mt-1">
              <input value={newCat} onChange={e => setNewCat(e.target.value)}
                     placeholder="Or type new category" className="form-control form-control-sm" />
              <button type="button" className="btn btn-sm btn-outline-secondary" onClick={addCategory}>
                Add
              </button>
            </div>
          </div>

          {/* Qty + Price */}
          <div className="row">
            <div className="col mb-3">
              <label className="form-label">Quantity *</label>
              <input name="quantity" type="number" value={form.quantity} onChange={handle}
                     className="form-control" required min="0" />
            </div>
            <div className="col mb-3">
              <label className="form-label">Price (₹) *</label>
              <input name="price" type="number" value={form.price} onChange={handle}
                     className="form-control" required min="0" step="0.01" />
            </div>
          </div>

          {/* Supplier */}
          <div className="mb-3">
            <label className="form-label">Supplier</label>
            <input name="supplier" value={form.supplier} onChange={handle}
                   className="form-control" />
          </div>

          <button type="submit" className="btn btn-primary me-2">
            <i className="bi bi-save me-1"></i>{editing ? 'Update' : 'Save'}
          </button>
          {editing && (
            <button type="button" className="btn btn-secondary"
                    onClick={() => onDone && onDone()}>Cancel</button>
          )}
        </form>
      </div>
    </div>
  );
}
