import { useState, useEffect } from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import { getStats } from '../utils/api';
// import {
//   Chart as ChartJS, CategoryScale, LinearScale, BarElement,
//   ArcElement, Tooltip, Legend, Title
// } from 'chart.js';
// Replace this import block at the top of Charts.js:
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement,
  ArcElement, Tooltip, Legend, Title
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend, Title);

export default function Charts() {
  const [stats, setStats] = useState(null);

  useEffect(() => { getStats().then(r => setStats(r.data)); }, []);

  if (!stats) return <div className="text-center py-5"><div className="spinner-border text-primary"></div></div>;

  const labels = stats.by_category.map(c => c.category);
  const qty    = stats.by_category.map(c => c.total_qty);
  const counts = stats.by_category.map(c => c.count);

  const COLORS = ['#4e79a7','#f28e2b','#e15759','#76b7b2','#59a14f','#edc948','#b07aa1','#ff9da7'];

  const barData = {
    labels,
    datasets: [{ label: 'Total Quantity', data: qty, backgroundColor: COLORS }]
  };

  const donutData = {
    labels,
    datasets: [{ label: 'Products', data: counts, backgroundColor: COLORS }]
  };

  return (
    <div>
      <h5 className="mb-4"><i className="bi bi-bar-chart-fill me-2 text-primary"></i>Inventory Analytics</h5>

      {/* Summary Cards */}
      <div className="row g-3 mb-4">
        {[
          // { label: 'Total Products', val: stats.by_category.reduce((s,c) => s + c.count, 0), icon: 'bi-box-seam', color: 'primary' },
          // { label: 'Total Quantity', val: stats.by_category.reduce((s,c) => s + c.total_qty, 0), icon: 'bi-layers', color: 'success' },
          // { label: 'Categories',    val: stats.by_category.length, icon: 'bi-tags', color: 'info' },
          // { label: 'Low Stock',     val: stats.low_stock.length, icon: 'bi-exclamation-triangle', color: 'warning' },
          { label: 'Total Products', val: stats.by_category.reduce((s,c) => s + c.count, 0), color: 'primary' },
          { label: 'Total Quantity', val: stats.by_category.reduce((s,c) => s + c.total_qty, 0), color: 'success' },
          { label: 'Categories',    val: stats.by_category.length, color: 'info' },
          { label: 'Low Stock',     val: stats.low_stock.length, color: 'warning' },

        ].map(card => (
          <div className="col-6 col-md-3" key={card.label}>
            <div className={`card border-${card.color} shadow-sm`}>
              <div className="card-body text-center">
                <i className={`bi ${card.icon} fs-3 text-${card.color}`}></i>
                <h4 className="mb-0 mt-1">{card.val}</h4>
                <small className="text-muted">{card.label}</small>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="row g-4">
        <div className="col-md-7">
          <div className="card shadow-sm p-3">
            <h6 className="text-muted mb-3">Quantity by Category</h6>
            <Bar data={barData} options={{ responsive: true, plugins: { legend: { display: false } } }} />
          </div>
        </div>
        <div className="col-md-5">
          <div className="card shadow-sm p-3">
            <h6 className="text-muted mb-3">Products per Category</h6>
            <Doughnut data={donutData} options={{ responsive: true }} />
          </div>
        </div>
      </div>

      {/* Low Stock Table */}
      {stats.low_stock.length > 0 && (
        <div className="card mt-4 border-warning shadow-sm">
          <div className="card-header bg-warning text-dark">
            <i className="bi bi-exclamation-triangle me-2"></i>Low Stock Alert (≤ 5)
          </div>
          <div className="card-body p-0">
            <table className="table table-sm mb-0">
              <thead><tr><th>Product</th><th>Category</th><th>Qty</th></tr></thead>
              <tbody>
                {stats.low_stock.map(p => (
                  <tr key={p.id}>
                    <td>{p.name}</td>
                    <td>{p.category_name || '—'}</td>
                    <td><span className={`badge ${p.quantity === 0 ? 'bg-danger' : 'bg-warning text-dark'}`}>{p.quantity}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
