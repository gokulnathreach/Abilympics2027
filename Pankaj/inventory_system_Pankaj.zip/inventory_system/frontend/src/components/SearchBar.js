import { useState, useEffect } from 'react';
import { getCategories } from '../utils/api';

export default function SearchBar({ onSearch }) {
  const [q, setQ]             = useState('');
  const [cat, setCat]         = useState('');
  const [categories, setCats] = useState([]);

  useEffect(() => { getCategories().then(r => setCats(r.data)); }, []);

  const search = (newQ = q, newCat = cat) => {
    onSearch({ search: newQ, category: newCat });
  };

  return (
    <div className="card mb-3 shadow-sm">
      <div className="card-body py-2">
        <div className="row g-2 align-items-center">
          <div className="col">
            <div className="input-group">
              <span className="input-group-text"><i className="bi bi-search"></i></span>
              <input value={q}
                onChange={e => { setQ(e.target.value); search(e.target.value, cat); }}
                placeholder="Search by name or supplier..."
                className="form-control" />
            </div>
          </div>
          <div className="col-auto">
            <select className="form-select" value={cat}
              onChange={e => { setCat(e.target.value); search(q, e.target.value); }}>
              <option value="">All Categories</option>
              {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div className="col-auto">
            <button className="btn btn-outline-secondary" onClick={() => {
              setQ(''); setCat(''); onSearch({});
            }}>Clear</button>
          </div>
        </div>
      </div>
    </div>
  );
}
