import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

// Products
export const getProducts  = (params) => api.get('/products/', { params });
export const getProduct   = (id)     => api.get(`/products/${id}/`);
export const createProduct= (data)   => api.post('/products/', data);
export const updateProduct= (id, d)  => api.put(`/products/${id}/`, d);
export const deleteProduct= (id)     => api.delete(`/products/${id}/`);
export const exportExcel  = ()       => api.get('/products/export/', { responseType: 'blob' });
export const getStats     = ()       => api.get('/products/stats/');

// Categories
export const getCategories   = ()     => api.get('/categories/');
export const createCategory  = (data) => api.post('/categories/', data);
