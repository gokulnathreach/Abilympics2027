from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.http import HttpResponse
from django.db.models import Q, Sum
import openpyxl

from .models import Product, Category
from .serializers import ProductSerializer, CategorySerializer


class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer


class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all().order_by('-created_at')
    serializer_class = ProductSerializer

    # ── Search ──────────────────────────────────────────────
    def get_queryset(self):
        qs = super().get_queryset()
        q = self.request.query_params.get('search', '')
        cat = self.request.query_params.get('category', '')
        if q:
            qs = qs.filter(Q(name__icontains=q) | Q(supplier__icontains=q))
        if cat:
            qs = qs.filter(category_id=cat)
        return qs

    # ── Export to Excel ──────────────────────────────────────
    @action(detail=False, methods=['get'])
    def export(self, request):
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Inventory"
        headers = ['ID', 'Name', 'Category', 'Quantity', 'Price', 'Supplier', 'Created']
        ws.append(headers)
        for p in self.get_queryset():
            ws.append([p.id, p.name, p.category.name if p.category else '',
                       p.quantity, float(p.price), p.supplier,
                       p.created_at.strftime('%Y-%m-%d')])
        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename="inventory.xlsx"'
        wb.save(response)
        return response

    # ── Stats for charts ─────────────────────────────────────
    @action(detail=False, methods=['get'])
    def stats(self, request):
        from .models import Category
        by_cat = []
        for cat in Category.objects.all():
            prods = Product.objects.filter(category=cat)
            by_cat.append({
                'category': cat.name,
                'total_qty': prods.aggregate(Sum('quantity'))['quantity__sum'] or 0,
                'total_value': float(
                    prods.aggregate(val=Sum('price'))['val'] or 0
                ),
                'count': prods.count(),
            })
        low_stock = ProductSerializer(
            Product.objects.filter(quantity__lte=5).order_by('quantity')[:5],
            many=True).data
        return Response({'by_category': by_cat, 'low_stock': low_stock})
