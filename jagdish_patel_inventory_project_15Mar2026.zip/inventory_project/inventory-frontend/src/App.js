import React, { useEffect, useState } from "react";
import { fetchItems, createItem, updateItem, deleteItem, exportExcel } from "./api";
import ItemModal from "./ItemModal";
import ChartModal from "./ChartModal";
import "bootstrap/dist/css/bootstrap.min.css";

function App(){

const [items,setItems]=useState([])
const [search,setSearch]=useState("")
const [show,setShow]=useState(false)
const [editId,setEditId]=useState(null)
const [showChart,setShowChart] = useState(false)
const [form,setForm]=useState({
name:"",
sku:"",
quantity:0,
price:0
})

useEffect(()=>{
loadItems()
},[])

const loadItems=()=>{
fetchItems().then(res=>setItems(res.data))
}

const openAdd=()=>{
setEditId(null)
setForm({name:"",sku:"",quantity:0,price:0})
setShow(true)
}

const openEdit=(item)=>{
setEditId(item.id)
setForm(item)
setShow(true)
}

const saveItem=()=>{

if(editId){
updateItem(editId,form).then(loadItems)
}else{
createItem(form).then(loadItems)
}

setShow(false)

}

const removeItem=(id)=>{
deleteItem(id).then(loadItems)
}

const downloadExcel=()=>{
exportExcel().then(res=>{
const url = window.URL.createObjectURL(new Blob([res.data]))
const link = document.createElement('a')
link.href=url
link.setAttribute('download','items.xlsx')
document.body.appendChild(link)
link.click()
})
}

const filtered = items.filter(i =>
i.name.toLowerCase().includes(search.toLowerCase()) ||
i.sku.toLowerCase().includes(search.toLowerCase())
)

return(

<div className="container mt-4">

<h2>Inventory Management</h2>

<div className="d-flex mb-3">

<input
className="form-control me-2"
placeholder="Search..."
onChange={(e)=>setSearch(e.target.value)}
/>

<button className="btn btn-primary me-2" onClick={openAdd}>
Add Item
</button>

<button className="btn btn-success" onClick={downloadExcel}>
Export Excel
</button>
&nbsp; &nbsp;
<button className="btn btn-info" onClick={()=>setShowChart(true)}>
View Chart
</button>

</div>

<table className="table table-bordered">

<thead>
<tr>
<th style={{width:"30%"}}>Name</th>
<th style={{width:"25%"}}>SKU</th>
<th style={{width:"10%"}}>Qty</th>
<th style={{width:"15%"}}>Price</th>
<th style={{width:"10%"}}>Action</th>
</tr>
</thead>

<tbody>

{filtered.map(item=>(
<tr key={item.id}>

<td>{item.name}</td>
<td>{item.sku}</td>
<td>{item.quantity}</td>
<td>{item.price}</td>

<td>

<button
className="btn btn-warning btn-sm me-2"
onClick={()=>openEdit(item)}
>
Edit
</button>

<button
className="btn btn-danger btn-sm"
onClick={()=>removeItem(item.id)}
>
Delete
</button>

</td>

</tr>
))}

</tbody>

</table>

<ChartModal
show={showChart}
handleClose={()=>setShowChart(false)}
items={items}
/>

<ItemModal
show={show}
handleClose={()=>setShow(false)}
handleSave={saveItem}
form={form}
setForm={setForm}
/>

</div>

)

}

export default App