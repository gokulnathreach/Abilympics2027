import React, { useState, useEffect } from "react";
import { Modal, Button, Form } from "react-bootstrap";

function ItemModal({ show, handleClose, handleSave, form, setForm }) {
  const [errors, setErrors] = useState({});
  useEffect(() => {
    if (show) {
      setErrors({});
    }
  }, [show]);
  const validateForm = () => {
    let newErrors = {};

    if (!form.name || form.name.trim() === "")
      newErrors.name = "Item name is required";

    if (!form.sku || form.sku.trim() === "") newErrors.sku = "SKU is required";

    if (!form.quantity || form.quantity <= 0)
      newErrors.quantity = "Quantity must be greater than 0";

    if (!form.price || form.price <= 0)
      newErrors.price = "Price must be greater than 0";

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  return (
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>{form.id ? "Update Item" : "Add Item"}</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <Form>
          {/* Name */}

          <Form.Group className="mb-3">
            <Form.Label>Item Name</Form.Label>

            <Form.Control
              type="text"
              placeholder="Enter item name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              isInvalid={errors.name}
            />

            <Form.Control.Feedback type="invalid">
              {errors.name}
            </Form.Control.Feedback>
          </Form.Group>

          {/* SKU */}

          <Form.Group className="mb-3">
            <Form.Label>SKU Code</Form.Label>

            <Form.Control
              type="text"
              placeholder="Enter SKU"
              value={form.sku}
              onChange={(e) => setForm({ ...form, sku: e.target.value })}
              isInvalid={errors.sku}
            />

            <Form.Control.Feedback type="invalid">
              {errors.sku}
            </Form.Control.Feedback>
          </Form.Group>

          {/* Quantity */}

          <Form.Group className="mb-3">
            <Form.Label>Quantity (Qty)</Form.Label>

            <Form.Control
              type="number"
              placeholder="Enter quantity"
              value={form.quantity}
              onChange={(e) => setForm({ ...form, quantity: e.target.value })}
              isInvalid={errors.quantity}
            />

            <Form.Control.Feedback type="invalid">
              {errors.quantity}
            </Form.Control.Feedback>
          </Form.Group>

          {/* Price */}

          <Form.Group className="mb-3">
            <Form.Label>Price (₹)</Form.Label>

            <Form.Control
              type="number"
              placeholder="Enter price"
              value={form.price}
              onChange={(e) => setForm({ ...form, price: e.target.value })}
              isInvalid={errors.price}
            />

            <Form.Control.Feedback type="invalid">
              {errors.price}
            </Form.Control.Feedback>
          </Form.Group>
        </Form>
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Cancel
        </Button>

        <Button
          variant="primary"
          onClick={() => {
            if (validateForm()) {
              handleSave();
            }
          }}
        >
          Save
        </Button>
      </Modal.Footer>
    </Modal>
  );
}

export default ItemModal;
