import React from "react";
import { Modal, Button } from "react-bootstrap";
import ChartComponent from "./ChartComponent";

function ChartModal({ show, handleClose, items }) {

  return (
    <Modal show={show} onHide={handleClose} size="lg" scrollable>

      <Modal.Header closeButton>
        <Modal.Title>Inventory Chart</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <ChartComponent items={items} />
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Close
        </Button>
      </Modal.Footer>

    </Modal>

  );
}

export default ChartModal;