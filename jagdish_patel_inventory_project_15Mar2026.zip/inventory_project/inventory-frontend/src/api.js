import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:8000/api/"
});

export const fetchItems = () => API.get("items/");
export const createItem = (item) => API.post("items/", item);
export const updateItem = (id, item) => API.put(`items/${id}/`, item);
export const deleteItem = (id) => API.delete(`items/${id}/`);
export const exportExcel = () => API.get("export-excel/", { responseType: "blob" });