import React from "react";
import { Tabs, Tab } from "react-bootstrap";
import { Bar, Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";

import ChartDataLabels from "chartjs-plugin-datalabels";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
  ChartDataLabels,
);

function ChartComponent({ items }) {
  /* Inventory Value Chart */

  const valueData = {
    labels: items.map((i) => i.name),
    datasets: [
      {
        label: "Inventory Value",
        data: items.map((i) => i.price * i.quantity),
        backgroundColor: "#4CAF50",
      },
    ],
  };

  /* Top 5 Stock Items */

  const topItems = [...items]
    .sort((a, b) => b.quantity - a.quantity)
    .slice(0, 5);

  const topStockData = {
    labels: topItems.map((i) => i.name),
    datasets: [
      {
        label: "Top 5 Stock Quantity",
        data: topItems.map((i) => i.quantity),
        backgroundColor: [
          "#2196F3",
          "#FF9800",
          "#9C27B0",
          "#009688",
          "#E91E63",
        ],
      },
    ],
  };

  /* Low Stock */

  const lowStock = items.filter((i) => i.quantity < 10);

  const lowStockData = {
    labels: lowStock.map((i) => i.name),
    datasets: [
      {
        label: "Low Stock Items",
        data: lowStock.map((i) => i.quantity),
        backgroundColor: "#F44336",
      },
    ],
  };

  /* NEW: All Stock Quantity Chart */

  const stockQtyData = {
    labels: items.map((i) => i.name),
    datasets: [
      {
        label: "All Stock Quantity",
        data: items.map((i) => i.quantity),
        backgroundColor: "#673AB7",
      },
    ],
  };

  const options = {
    plugins: {
      datalabels: {
        color: "#000",
        anchor: "end",
        align: "top",
        font: { weight: "bold" },
      },
    },
  };

  return (
    <Tabs defaultActiveKey="value">
      <Tab eventKey="stock" title="All Stock Quantity">
        <div className="mt-3">
          <Bar data={stockQtyData} options={options} />
        </div>
      </Tab>

      <Tab eventKey="value" title="Inventory Value">
        <div className="mt-3">
          <Bar data={valueData} options={options} />
        </div>
      </Tab>

      <Tab eventKey="top" title="Top 5 Stock">
        <div className="mt-3 d-flex justify-content-center">
          <div style={{ width: "350px", height: "350px" }}>
            <Pie data={topStockData} />
          </div>
        </div>
      </Tab>

      <Tab eventKey="low" title="Low Stock Warning">
        <div className="mt-3">
          <Bar data={lowStockData} options={options} />
        </div>
      </Tab>
    </Tabs>
  );
}

export default ChartComponent;
