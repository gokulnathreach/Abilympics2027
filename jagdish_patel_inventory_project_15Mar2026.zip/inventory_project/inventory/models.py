from django.db import models

class Item(models.Model):
    name = models.CharField(max_length=100)
    sku = models.CharField(max_length=50, unique=True)
    quantity = models.PositiveIntegerField(default=0)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Transaction(models.Model):
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    change = models.IntegerField()  # + for inbound, - for outbound
    description = models.CharField(max_length=255)
    timestamp = models.DateTimeField(auto_now_add=True)
