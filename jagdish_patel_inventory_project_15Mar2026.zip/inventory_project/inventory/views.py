from rest_framework import viewsets
from .models import Item, Transaction
from rest_framework.decorators import api_view
from django.http import HttpResponse
import pandas as pd
from .serializers import ItemSerializer, TransactionSerializer

class ItemViewSet(viewsets.ModelViewSet):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer

class TransactionViewSet(viewsets.ModelViewSet):
    queryset = Transaction.objects.all()
    serializer_class = TransactionSerializer

@api_view(['GET'])
def export_items_excel(request):

    items = Item.objects.all().values()

    df = pd.DataFrame(items)

    # Remove timezone from datetime fields
    if 'created_at' in df.columns:
        df['created_at'] = pd.to_datetime(df['created_at']).dt.tz_localize(None)

    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )

    response['Content-Disposition'] = 'attachment; filename=items.xlsx'

    df.to_excel(response, index=False)

    return response